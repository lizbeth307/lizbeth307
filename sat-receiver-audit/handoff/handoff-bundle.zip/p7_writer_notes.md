## block+rf
I wrote all four files for the "block+rf" group. Both SVGs pass the XML check you specified. My generator also checked that no text leaves the canvas or overflows its box, that boxes don't overlap, and that no line runs through a box. I had no SVG renderer here, so I haven't seen the drawings visually.

**Files written** (in `/home/user/lizbeth307/sat-receiver-audit/build/`):
- `01-blok-skhema.svg` (56,421 B): block diagram of the whole device. It covers:
  - antenna kits (patch tier, folding tier), the QO-100 add-on, Lime-only antennas and the gated optional parts
  - the 11 case bulkheads, the RF compartment (front ends, the 5-channel injector board with 3× HMC7992, the HF+ input switch, GNSS input)
  - the receivers: RTL-A/B/C with serials LABRXA/LABRXB/LABRXC, HF+ and Lime as the default build
  - the USB tree (blue J5 port, FE1.1s hub, CH334F hub), the Q6A and its buses
  - storage, display, the Pico HMI/supervisor, the MCP23017 expanders (#1, #3, #4), GNSS/IMU/RTC
  - the power tree, the bench kit as a separate block, a legend and the title block
- `01-blok-skhema.md` (20,931 B): a short paragraph per block with STACK.md section references, 8 signal paths, and a TBD list.
- `03-rf-trakt.svg` (61,688 B): RF schematic, one row per input: P1, P2, P8 to RTL-A; P3, P4 and BENCH to RTL-B; the Lime RX1, RX2, REF IN and TX port (X1) paths; P5 and P6 through relays K1/K2 to the HF+; P7 to the GNSS module; and the LAB USB-A port. It shows bias channels with current limits, DC-block part numbers, switch throws and the receive-only guards (Lime TX into a 50 Ohm load, TXEN register = 0).
- `03-rf-trakt.md` (25,930 B): per-input chain table, switch details, cascade and gain plan, a 26-row target table (target, frequency, antenna tier, chain, SDR, sample rate, decoder), and the bias/DC safety rules.

**STACK.md sections used:** §0 (header, rules and labels), §1.1 C1/C18, §1.2, §2.1–§2.11.3, §3 (lab rule), §3.1–§3.3, §4.1, §4.2, §5.1, §5.2, §5.3 (main source), §5.4, §5.8 and §8, plus decisions D1–D4, D6–D19.

**Marked TBD, because STACK.md leaves them open:**
- The third HMC7992's output to RTL-B has no pin number, and its two control lines are not assigned to any expander line.
- How the LIME RX1 port on the case connects to the RX1 jack on the injector board is not described.
- The case port for the BENCH/sled input is not named; §2.10 only names a connector on the board edge.
- The S-band LNA is unnamed, so its power and its order relative to the cf2235-kt30 resonator are open.
- The panel TVS on P2/P3 is optional and has no current part.
- Several protection values depend on measurements: final current-limit resistors for RTL-A/B and HF+ power (1.5–2× measured current), the LNB eFuse resistor, the upper Boni current limit, and the Boni overvoltage divider for 13.8 V.
- The LNB attenuator (15, 20 or 30 dB) is chosen on the bench.
- The Lime's second receive input is X3 or X4, to be checked against the board marking.
- Sample rates are not given for UHF, 2 m, Inmarsat-C, H1, ADS-B, AIS, FM-RDS, VOR or radiosondes.
- The MCP23017 #4 address (0x23) is "assign on schematic".
- In the block doc only: the LIME3V3 load switch is a bench choice, the blower model is unchosen, and the Wisecoco display waits on the seller's written answers.

**Conflict inside STACK.md:** the §2.3 switch row says 1 nF on RTL-B's common port (RFC-B), but the §5.3 rule (G3) says 100 pF on all RTL-B pins. The drawings follow §5.3, and `03-rf-trakt.md` flags it to check at layout.

## power+wiring
Power+wiring group: all four files are written. Both SVGs pass the minidom check and an overlap check for text, boxes, net flags and lines. They have a white background, no scripts, no external references, and a title block with "v2, 18.10.2026", units and «теоретичний проєкт — перевірити на стенді». This group writes no CSV.

**Files** (all in `/home/user/lizbeth307/sat-receiver-audit/build/`):
- `02-zhyvlennia.svg` (54,391 B): power schematic with net labels. It shows the pack → BMS → 7.5 A fuse → INA228 shunt → node N → #2813 → SW chain, the N domain (charger IP2368 behind TPS259470A, AON TPS70933, MCP65R41 UV supervisor, 5 A service port) and the Q6A domain (VCC_5V_PERI, 3V3_Q6A, LIME3V3). Five columns cover SYS12/J21/DISP12/AUX12, LAB5 with the four TPS2553DBVR-1 keys, LNA4V5 ch1-ch4 at 88.7k/162k (D14), LNB13V2 and BONI13V8 (D15). It also has the EN map, runtime table, cut-off levels and back-feed rules.
- `02-zhyvlennia.md` (37,770 B): topology, rail table (rail, source, regulator, V, I limit, protection, EN, default, loads), current-protection summary, AON/supervisor details, charger, back-feed rules, cut-off table, power-up and power-down order, runtime per mode, power BOM, TBD list.
- `04-pidkliuchennia-pinout.md` (37,493 B): 40-pin header map, I2C buses and addresses, UARTs, maps for MCP23017 #1, #3, #4 (D12) and #2 (sled), HMI expander PI4IOE5V9555, USB map with VBUS limits and the RTL-B VBUS path (D13), V4L serial names LABRXA/B/C (D2) and udev names, 30 case-panel connectors, a 30-line cable schedule, Pico GPIO map, TBD list.
- `04-header-40pin.svg` (25,880 B): the 40 pins colour-coded into 10 function classes, with legend, notes and title block.

**STACK.md sections used:** §5.1, §5.2, §5.3 (case RF ports, switches), §5.8 (panels and openings, interior layout), §2.6 (HDMI cable), §2.7 (all power BOM rows), §2.9, §2.10, §2.11.1 (CAB.01075), §8 (open power decisions, MCP23017 #4 line allocation, HF-7, HF-8, RF-2, TPS2553 tests), §9.2 steps 3 and 11. Decisions D2, D3, D12-D18.

**Marked TBD, and why:**
- **Unchosen parts or settings** (STACK.md §5.1, §8): the LIME3V3 load-switch part and its current limit (picked on the bench), and RILIM for the VBUS HF+, RTL-A and RTL-B keys (1.5-2× measured current).
- **To recalculate or measure:** the BONI13V8 OVLO divider ("перерахувати"), the final LNB RILM (after measuring the LNB current) and the DISP12 ILIM of 1.5 A vs about 1.7 A ("розглянути").
- **No values given:** resistor values for the three TPS259470A (STACK gives only targets), the LC pi-filter and Schottky part numbers, and the channel split between the two INA3221.
- **Left to you or the bench:** the LNB voltage window (±0.35 V or 11.5-14 V), the TVS from OUT to IN on the USB-C eFuse, 3.3 V on the header after poweroff, the GP17 dimming path and GP22 fan tacho.
- **Expander lines** (STACK.md §5.2, §8): MCP23017 #4 lines and its 0x23 address ("призначити на схемі"), the line numbers of the 14 MCP #3 inputs, control lines of the third HMC7992, the button and encoder bits on PI4IOE5V9555, and MCP #2 bits.
- **One conflict, flagged but not resolved:** the USB map and D13 send the RTL-B FAULT to MCP #3, but MCP #3 already uses all 16 lines. The HF+ and RTL-A FAULT lines are not assigned anywhere either.
- **Header and case details not in STACK.md:**
  - GND and unused pin numbers on the 40-pin header (I used the standard 40-pin layout, starred, to be checked against the Q6A v1.21 schematic). STACK also does not say which pin of the pairs 8/10, 13/15, 16/18 and 27/28 is SDA/SCL or TX/RX.
  - Where the power button and the node-N service port sit on the case.
  - Most internal wire and harness lengths, the LAB BUS cable length, the DISP12 barrel connector type, and whether RTL-A on H2 uses a Lindy 36700 extension.

## tests+bom
I wrote the three "tests+bom" files to `/home/user/lizbeth307/sat-receiver-audit/build/`, all in Ukrainian. The CSV passes the csv.reader check (146 rows, 16 columns each). A script that sums the CSV rows reproduces every group and tier subtotal in STACK.md §2.12 and §3.6 to the cent. Both .md files have consistent table column counts. There are no SVGs in this group.

**Files**
- `/home/user/lizbeth307/sat-receiver-audit/build/09-testy.md` (151,404 B): the full test plan. Each test gives the setup (conducted only), procedure, pass value, what to record, when (gate, deadline or bring-up step) and the STACK.md section it comes from. It covers:
  - receive-only rules, return windows and the gate calendar;
  - board bring-up checks (B1–B14, kernel, UFS);
  - the receive-only and policy self-tests: TX streams cannot open, bias token, rfkill, band masks, egc-gate, DSC/SITOR/WEFAX allow-lists, ADS-B/AIS privacy filters, SatDump/SDRangel/OpenWebRX+ audits, location without city tables;
  - the power-board bench, including TPS2553 trips at 265/299/339, 144/166/192 and 685/747/817 mA, the HF+ 5.3 ms inrush check, the eFuses, the sealed 4.2 A / 60 min regulator run and its spur A/B, and the expanders including MCP #4;
  - battery and charging, USB bandwidth and VBUS, and the D10 A/B matrix with per-band noise floor, display harmonic scan and HRPT spur gate;
  - RF parts acceptance, the display (brightness, power, touch, BLE, dimming), thermal, mechanics and weather;
  - the NPU gate, Lime acceptance within 30 days (L-0…L-12 and T7 (1)–(7)), every lab instrument's per-analog acceptance (P5), procedures P0–P21 with formulas, field tests, and the open questions.
- `/home/user/lizbeth307/sat-receiver-audit/build/10-bom.csv` (63,911 B): 145 parts, one row per STACK.md BOM line. Sets stay as sets at the set price, with every part number listed. Columns include tier, whether the row counts in the tier total, numeric min/max USD, the EU price with VAT or landed price, status, and the condition for conditional replacements.
- `/home/user/lizbeth307/sat-receiver-audit/build/10-bom.md` (20,715 B): per-tier totals, summary roll-ups, group composition, the budget variant, the EU landed-cost rule, the §9.1 shopping order (13 steps, longest lead times first), a deadline table with the Lime decision before 1.12.2026 in bold, authenticity rules and the TBD list. Headline totals:

| Tier | USD |
|---|---|
| core with Lime | 2,523.01–2,843.48 |
| core without Lime | 1,916.55–2,235.02 |
| Lime set | 606.46–608.46 |
| patch | 175.79–201.79 |
| QO-100 | 97.41–124.46 |
| folding | 542.26–612.99 |
| lab core | 1,609.39–1,767.80 |
| lab extended | 582.23–629.73 |
| optional | 272.52–289.58 |

**STACK.md sections used:** 1.1/1.2 (C4, C11, #11), 2.1–2.12, 3 (lab rule), 3.1–3.6, 5.7, 8, 8.1, 8.2, 9.1, 9.2, plus decisions D1–D19 (D2 serials, D3 token path, D6 7 Msps floor, D7 Airspy Mini gate, D8, D9, D11, D12 MCP #4, D13 RTL-B VBUS, D14 TPS2553 values, D15 Boni eFuse and reflow, D17, D18, D19).

**Marked TBD, because STACK.md leaves them open or unpriced:**
- Lime M.2 3.3 V load switch (part "не визначено", §2.11.1 and §8).
- MCP23017 #4 address 0x23 and its lines, "призначити на схемі" (D12).
- 5 V blower model (§2.1) and the filter LC parts (§2.7).
- Fibreglass tape, 4S wrap and XT60-XT30 lead (no price).
- Vendor for the UV divider's bottom resistors and the Schottkys (§9.1 step 6).
- Piezo acoustic vent, LED window and IP67 SMA feedthroughs (no SKU, §2.9).
- 4D OSD board (price on request).
- Extra SMA attenuator for H1 on the Lime path (≥12 dB total; §8 names no value or part).
- S-band LNA (not named).
- Case TSA locks, hub power lead, Boni 5.5/2.1 mm plug, 240 W EPR cable, connector savers, BNC DC-block for the Hantek, LM4040 and the test NVMe 2230 (unpriced).
- LNB bus 13.2 V vs 12.5 V and its tolerance window (owner decision, §8).

**One inconsistency inside STACK.md §2.12:** the prose paragraph gives EU-landed lower bounds of ≈$4,965–5,641 and ≈$5,535–6,

## mech+antennas
I wrote all six files for the mech+antennas group in `/home/user/lizbeth307/sat-receiver-audit/build/`. Every SVG passes the `xml.dom.minidom` check, and none has scripts or external references. Each SVG has the title block with the name, "v2, 18.10.2026", units, and «теоретичний проєкт — перевірити на стенді». I rendered each one to PNG to check for text running off the canvas or over other labels, and fixed what I found. Two things need saying up front: the layout plan and section are zoning sketches, not coordinates, and many positions and hole sizes are marked TBD because STACK.md leaves them open.

**Files**
- `05-mekhanika.md` (37.4 KB): envelope and materials, front face and HMI, a 22-row part placement list, the layers from front to back, and every port per wall (type, hole, bias, internal path, cap). It also covers clearances, the two cooling air paths and heat paths into the plate, sealing to IPX4/IP54, the mass budget, mechanical acceptance checks and a TBD table.
- `05-roztashuvannia-front.svg` (16.3 KB): front view with the display, hood hinge (plus a side inset of the hood open and closed), the HMI column with encoders and the 2x3 buttons, VEML7700, and the top-edge ports at 20 mm pitch. Dimensions are in mm.
- `05-roztashuvannia-section.svg` (24.7 KB): one side section that projects parts from different places onto a single plane. It shows the display stack, the 4-6 mm air channel and blower, the 2 mm plate with fins, the Q6A with cooler and Noctua fan, the Lime on its pedestal and riser, the RF bay, the HF+ can, the battery bay with barrier and vent, IP2368, the T7 holder, the 1/4-20 nut boss and GX16-4. A plan of the zones sits alongside.
- `05-roztashuvannia-panel.svg` (26.2 KB): drawings of each wall. Top edge: P1-P8 and RX1. Left wall: RX2 and REF IN. Right wall. Bottom edge: USB-C, LAB USB-A, LAB BUS, 3.5 mm audio, T7 cable seal, air intake. Rear wall: GX16-4 (16 mm hole, 18.8 mm nut, about 46 mm mated), 1/4-20 nut boss, service hatch, strap lugs and slots, fan exhaust and intake, T7 holder. A hole and part legend is included.
- `06-anteny.md` (39.7 KB): a summary table of all antennas (tier, targets, connector, port, bias, packed and deployed size, price). It then covers build dimensions and setup for each antenna. Orientation is computed from the GNSS fix, with the V-dipole rule, the QO-100 skew formula, the GEO visibility gates and a symbolic elevation formula. Acceptance is receive-only (DMM continuity, conducted checks, noise floor, beacons, sun noise, A/B tests; no S11 on air). Deploy times, packing checklists, outdoor safety and a TBD table follow.
- `06-anteny-komplekty.svg` (58.4 KB): 15 panels showing each antenna packed and deployed with key dimensions. Panels 1-7 are the patch tier, 8-14 the folding tier, and 15 is packing. There are no loops and no dishes, and the HF wire is labelled as an open wire.

**STACK.md sections used:** §1.1 C15 and D15; §2.4, 2.5, 2.6, 2.8, 2.9, 2.10, 2.11.1, 2.11.2, 2.11.3; §4.1-4.3; §5.3; §5.6; §5.8; §11.4; §11.5. From the decisions file: D8, D9, D16, D17, D18, D19.

**Marked TBD, and why** (STACK.md leaves these open or gives no value):
- The display bezel, which STACK.md says is drawn only after the panel passes acceptance; also the glass/panel stack thickness and the active area, which must be measured.
- The volume knob diameter (Adafruit 2055) and the order of the button rows.
- Hole sizes for F (P4), BNC (P5), SMA-K (P7) and the Taoglas CAB.01075 bulkheads (RX1, RX2, REF IN).
- Exact positions:
  - where the port row sits on the top edge, by depth and distance to the edges;
  - the order of items on the bottom edge;
  - which side the path-2 air exhaust uses;
  - where items sit on the rear wall.
- Which side of the plate the Lime sits on and its coordinates; the Lime 3.3 V power switch part; the depth of the RF bay; where the LC76G board goes; and whether the battery bay's 54 mm or 33 mm runs front to back.
- SKUs not given: the LED window, the piezo acousti

## software+assembly
Я записав обидва файли, які призначено групі "software+assembly". SVG і CSV у цій групі немає, тож XML/CSV-валідацію не запускав. Обидва файли — Markdown українською, з шапкою «v2, 18.10.2026» і позначкою «теоретичний проєкт — перевірити на стенді». Значення взято зі STACK.md v2 і рішень D1-D19, біля кожного стоїть посилання на розділ STACK.md. На заборонені формулювання файли перевірено grep-пошуком: збігів немає, лише заборонені TX-рядки Dream, які CI якраз перевіряє.

**Файли:**
- `/home/user/lizbeth307/sat-receiver-audit/build/07-pz-vstanovlennia.md` — 51,459 B, встановлення ПЗ, 25 розділів:
  - образ, утримане ядро 6.18.2-4 з хешами, apt-mark hold;
  - aptly з пріоритетами 1001/990/−1 і повним списком пінів −1;
  - маршрути завантаження A/B, повний рядок cmdline;
  - оверлей lab-q6a.dtso: UART6/UART7, I2C0/I2C2, PPS на піні 7 (GPIO96), FastRPC, вимкнення pcie0; DKMS pps-gpio;
  - librtlsdr +lab із воротами bias через /run/labd/bias/<serial> (D3) і серійними LABRXA/B/C (D2); libairspyhf 1.6.8-4build1 (D4); модулі SoapySDR; LimeSuiteNG із заблокованим TX;
  - SatDump за D1, gr-satellites, алоу-листи збірок SDR++ і SDRangel, режими OpenWebRX+;
  - readsb і AIS-catcher з фільтрами dbFlags &1/&4/&8 і типу 35 (D11), lab-wsjt-decoders (D5);
  - gpsd/chrony/PPS і команди LC76G, Gpredict лише на прийом, сервіси lab* з пісочницями оренд;
  - перелік заборонених пакетів, таблиця з 18 перевірок CI, які доводять відсутність TX і приватних шляхів, і перелік TBD.
- `/home/user/lizbeth307/sat-receiver-audit/build/08-zbyrannia.md` — 58,797 B, збирання, 18 кроків (0-17) у заданому порядку:
  - інструменти і безпека; літієвий пак; зарядник IP2368; силова плата лише оплавленням;
  - середня пластина і РЧ-відсік; Q6A з охолоджувачем; Lime на riser з п'єдесталом;
  - приймачі і вхідні каскади; перемикачі й інжектори; екран HF+ із перемикачем G6K;
  - дисплей і козирок; HMI; пак GNSS/IMU (GX16-4, D18); джгут; закриття і герметизація корпусу;
  - перше ввімкнення від джерела з обмеженням струму; далі ПЗ.

  Кожен крок має структуру «Деталі → Дія → Перевірка» з порогом проходу зі STACK.md і перелік TBD у кінці.

**Використані розділи STACK.md:** 1.1 (C4, C5, C6, C7, C11, C13, C14, C16, C22, D6, D12, D13), 2.7, 2.9, 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.8, 8.1 (V4L-0..V4L-8), 9.1 (кроки 1-13), 9.2 (кроки 1-14). Рішення: D1-D6, D11-D15, D18.

**Позначено TBD і чому** (STACK.md лишає ці значення відкритими або не наводить їх):
- **Адреса MCP23017 #4 (0x23):** «призначити на схемі» (5.2, 8).
- **Лінія TLMM WIFI_PWR_EN для польового блокування Wi-Fi:** знайти у W1-2 (5.2).
- **Ключ навантаження LIME3V3:** «обирається на стенді» (5.1).
- **Набір FastRPC і прошивка DSP 0.2.29 чи 0.2.42:** вибір матриці Phase 0 (5.4).
- **Маршрут завантаження A чи B:** маршрут A ще не підтверджено на образі (5.4).
- **Offset NMEA у chrony:** це виміряна медіана (C13).
- **Остаточний RILM eFuse LNB:** після виміру струму LNB (5.1, 9.1 крок 11).
- **OVLO eFuse Boni для 13.8 V:** у STACK.md «перерахувати» (5.1).
- **Номінали резисторів TPS259470A:** задано лише OVLO/ILIM (5.1).
- **RILIM каналів VBUS HF+ і RTL-B:** 1.5-2× виміряного струму (5.1).
- **Атенюатор ПЧ LNB 15/20/30 dB:** вибір на стенді (5.3).
- **Охолоджувач A чи B і товщина прокладок Gelid:** за примірки в STEP V1.21 (5.8).
- **Верхній ключ вентилятора шляху 1 і GP22:** «перевірити на схемі P7» (5.2).
- **Шлях димінгу дисплея і розміри безеля:** лише після приймання панелі.
- **Хеші прошивок Lime і пакетів radxa-dragon-q6a 6.18.2-4:** у STACK.md значень немає.
- **Назви origin aptly:** STACK.md задає лише пріоритети.
- **Аргументи CLI `satdump live`:** STACK.md їх не наводить.
- **Ліміт струму, модель лабораторного джерела й електронного навантаження:** 9.2 не задає.
- **Регулятор SYS12 (D36V50F12 чи LM61460):** рішення A/B у 9.2 крок 4.

Окремо: імена опцій CMake для SatDump і SDR++ я записав за назвами модулів зі STACK.md і позначив «звірити з CMakeLists.txt закріпленого коміту». Самі значення я не вигадував.

