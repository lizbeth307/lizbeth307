# Orchestrator decisions for the STACK v2 fix pass (apply consistently everywhere; they settle conflicts between sources of equal precedence)

D1 SatDump input: keep the live path AND file decode. Build: -DPLUGINS_ALL=OFF plus METEOR, NOAA_METOP, AWS, ELEKTRO_ARKTIKA, XRIT, FY2 and NET_SOURCE_SDR_SUPPORT only. Every other sdr_sources plugin (hardware, Soapy, LimeSuiteNG, remote) stays OFF. NET_SOURCE listens only on 127.0.0.1 and receives cf32 UDP from labrx after the masks; decoding from recorded files is the default. No GK2A/FY3/FY4/GOES/METOPSG/ANALOG/CUBESAT/RADIOSONDE plugins (no Europe pipeline). Reason: re-audit A requires the live path; re-audit C's aim (SatDump never opens an SDR and has no TX-capable source) is still met. Write it the same way in 1.1 C7, 1.2 #30, 5.4, 6.2, 8 and 11.2/11.4.
D2 V4L serial names: LABRXA = RTL-A, LABRXB = RTL-B, LABRXC = spare, pattern ^LAB[A-Z]{3}$, everywhere (C5, C21, 8.1 V4L-4, 11.3 ...; rtl_test -d LABRXB).
D3 Bias-tee token path: /run/labd/bias/<serial> everywhere.
D4 libairspyhf: default noble libairspyhf1 1.6.8-4build1 (held, 990 mirror); the 1.6.8-5~lab1 / 1.8.1 backport is only an option; the bias-tee API symbols exist only in the 1.8.1 build.
D5 WSJT-X decode-only package name: lab-wsjt-decoders everywhere.
D6 Lime sample-rate floor: 7 Msps everywhere (6 Msps stays only as the Airspy Mini's own rate).
D7 Airspy Mini purchase gate as analogs G6 #12: buy only if (a) the 15-min 2.88 Msps rtl_test on the blue port is not lossless OR (b) the Metop hump is seen but the V4L cannot decode; skipping the buy because the Lime passed a 15-min lossless 7 Msps capture is only an optional scope choice for the user.
D8 QO-100 add-on and LNB: "купується" (to be bought, step 11 of 9.1), never "куплено".
D9 No city tables: replace per-city elevation angles with regional bands (operator note 19 wording); the device computes its own angle from the GNSS fix. City coordinates may stay only as CI test fixtures in section 8, without angle tables.
D10 HF WEFAX: NWS stations run by the USCG are excluded by rule (military operator), not an open question; delete the user question about them.
D11 ADS-B and AIS: only readsb and AIS-catcher (dbFlags &1/&4/&8 hidden, AIS type-35 suppressed); SDRangel demodadsb/demodais and the OpenWebRX+ adsb/ais modes are not built.
D12 Expander lines: MCP23017 #1 and #3 are 16/16 used. LIME3V3 load-switch EN and LC76G RESET get lines on a new MCP23017 #4 (MCP23017-E/SO, same seller and unit price as the existing MCP23017 line; next free I2C address on that bus, marked "призначити на схемі"), unless 5.2 shows free lines on the PI4IOE5V9555/TCA9555 HMI expander, in which case use those. Add an open item in 8 and update the BOM count and subtotal.
D13 RTL-B VBUS: defined path LAB5 -> TPS2553DBVR-1 (EN from MCP #1 GPA3) -> split-VBUS lead to RTL-B (pad 1 unconnected, as for H2); add it to the 5.2 USB map and the 5.1 LAB5 load list.
D14 TPS2553DBVR-1 at 88.7k: 265/299/339 mA (G3 #11) everywhere; the TCBT-2R5G+ channel is only ch4 WIDE on 162k; sum 3 x 299 + 166 mA ~ 1.06 A (model). HF+ VBUS channel: 100 + 220 uF ~ 5.3 ms is above the 5 ms minimum FAULT deglitch, so it must pass the inrush test; fallback TPS2553DBVR (auto-retry, LCSC C55266) on that channel only.
D15 Boni rail: BONI13V8 13.8 V with eFuse TPS259630DDAR (RILM 7.87k), no PTC; MF-MSMF030-2 is not bought. TPS259470ARPWR x3 (J21, DISP12, USB-C VBUS): the power board is reflow-only.
D16 Gender-neutral wording everywhere (no "користувач прийняв"; use "ви" or "рішенням 18.10.2026").
D17 The Lime is never optional or "if kept": with-Lime is the default build; the no-Lime build is only the fallback if the Lime fails acceptance.
D18 IMU connector: Olimex GX16-4 with tethered cap everywhere (no GX12/M8).
D19 Bench case: B&W outdoor.case Type 4000 RPD (conditional: eyelets locked when carried), Peli 1450 as fallback; Apache 3800 removed.
