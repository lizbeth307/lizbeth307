# User requirements (consolidated 18 Oct 2026; governing input for every later phase)

Project: a handheld, standalone (no phone), RECEIVE-ONLY satellite receiver that is also a complete portable radio laboratory. The user wants maximum effort and full agent scale, objective decisions that weigh these wishes, and a finished, theoretically working stack with a final schematic and assembly instructions in files.

Hard rules
- Receive-only on air. Signal-generating instruments (VNA, generators, noise sources) are conducted bench tools only.
- No decoding of private-communications content (Iridium/Inmarsat/Orbcomm user traffic, Starlink user data) and no receive chains aimed at military communications; generic SDR frequency coverage is fine.
- Compute stays: Radxa Dragon Q6A (no alternative search for it).
- No dishes of any size.
- Antennas allowed: patch and chip antennas, plus antennas that fold/collapse into a small size (prefer every piece <= 20-23 cm, at most about 35 cm); deployed size may be larger.
- NO loop antennas of any kind: the HF active loop and everything for it, and the 20 cm / 12 cm VHF loops for Meteor, were removed by the user. Meteor LRPT uses the foldable telescopic V-dipole.
- The user is not in Ukraine and has not named a country: use world prices (manufacturer, AliExpress, EU/US shops); Ukrainian prices only as a reference.
- The device determines its own location automatically (GNSS + plausibility gate + fallbacks); no city tables.

Functional wishes
- Display: bright and high quality, ideally above Full HD. Objective audit result: a bonded 7in FHD 2000-nit panel (Wisecoco, conditional on bonding + USB-HID touch confirmation; fallback 4D Systems 1000-nit bonded) beats dim above-FHD kits; above-FHD only as a Midas 1200x1920 bring-up project.
- Full radio lab: instruments (VNA, spectrum analyzer, noise source, GPSDO/reference, power meter, near-field probes, attenuators, loads), RF switch and filter/LNA banks, extra receive capabilities (HF, LF/VLF time signals, ADS-B, AIS, radiosondes, broadcast, radio-astronomy basics), lab software, bench tools.
- HF receiver (keep), with a small foldable NON-loop antenna.
- NPU training system ON THE SPECTRUM: detect and classify signals on the waterfall; the user teaches it by marking signals; on-device few-shot learning plus home-base training; INT8 for QAIRT 2.42.
- One ideal touch MENU system through which every lab function is easy to use (gloves, sun, one hand, robust).

Process the user asked for (pipeline)
1. Finish all research. 1b. Agents research and verify the report I keep writing (minute-log.md, summaries.md, extra-studies.md, final/*.json).
2. Final checks (integration + completeness, then sourcing). 3. Consolidated STACK.md. 4. Full re-research of the whole stack at maximum agent scale.
5. Cheapest analogs that are NOT worse in quality or performance for every part EXCEPT the Q6A and the antennas, with adversarial verification.
6. Re-verify the stack with the analogs. 7. Complete schematic (block, power, RF, wiring/pinout), placement and mechanical drawing (SVG), software install plan, assembly and test instructions as files in sat-receiver-audit/build/.
- Per-minute summaries are not shown to the user; they are kept in sat-receiver-audit/minute-log.md.
- The user is asleep and delegated all remaining decisions: decide objectively, weighing these wishes; report at phase ends.

Decisions I made under the delegation after P1 (18 Oct 2026; revisit if the user objects)
- "No loops" also excludes H-field (small shielded loop) near-field probes and the AS3935 ferrite-coil lightning sensor by default; only E-field near-field probes are used. Trade-off accepted: the Airspy HF+ with a wire (feed point 5-10 m from the handheld) will often be limited by local noise.
- Field/QUIET mode: rfkill block wlan AND bluetooth; Pinecil IronOS Bluetooth = Off; FNB58 Std (no radio).
- Universal Radio Hacker (URH) is rejected (archived; record-and-send and attack features). The Artemis/sigidwiki database is used for identification only: a match to a military or government entry is logged as out of scope and not recorded, analysed, annotated or decoded further.
- NPU class policy gate: no radar, drone/FPV/RC link, EW/jammer, military, emitter-fingerprint or private-content classes; voice is spectrogram-only; decoder payloads are never stored.
- The radio-lab core kit follows the value verifier: Bodnar Mini GPSDO moves to extended (GNSS-SDR + PPS give ppm for free), no duplicate OSL kits, no AD8318 in core.
- VLF SID logging of 16-25 kHz carriers is DROPPED: those beacons are naval submarine-communication transmitters, so it would be a receive chain aimed at military transmitters. Space-weather SID logging may use only civilian LF carriers (DCF77 77.5 kHz, MSF/WWVB 60 kHz, JJY 40/60 kHz, TDF 162 kHz), amplitude only.
- Inmarsat-C: only EGC SafetyNET (public maritime safety broadcast) is in scope. Physics caveat (P1b): SafetyNET shares the NCS TDM carrier with other packets, so the bit stream is necessarily demodulated and FEC-decoded before a packet header can be read. Rule therefore: parse only packet headers/type; any packet that is not EGC SafetyNET is discarded at header level, its payload never reassembled, converted to text, displayed, logged or stored; LES/ship message channels are not tuned at all; FleetNET (commercial subscription broadcast) is also discarded.
- Power meter wish: covered by the level-calibrated tinySA (channel power) in core; a log-detector power meter (AD8318 class) is optional in extended, since it cannot be more accurate than the tinySA it is calibrated against.
- Location fallback without GNSS must not use a city table: use last good fix with age, manual lat/lon entry, or Wi-Fi-free methods only (no city list).
- (P2, 18 Oct) No emitter geolocation: no bearing logs from the IMU heading, no GNSS-tagged per-emitter heat maps, no SDRangel Heat Map plugin, no DF/AoA/emitter tracks. Spectrum surveys store band occupancy only.
- (P2) Survey band mask: generic surveys and NPU "unknown_energy" boxes do not store, label or log activity inside military bands (at least 3-30 kHz VLF, 225-400 MHz incl. 240-320 MHz SATCOM and 360-380 MHz MUOS); those bins are masked to "no data" before storage. Coverage of the SDRs is unchanged; only logging is masked.
- (P2) DSC: only distress/urgency/safety categories; the decoder drops routine and individual calls at the format/category field, before addresses (MMSIs) are decoded or shown. SITOR-B, RTTY, CW and PSK skimmers run only on amateur bands and published MSI/NAVTEX channels; no utility-traffic printing elsewhere. HF WEFAX: only civil meteorological broadcasts; stations run by military operators (e.g. Northwood) are excluded.
- (P2) Voice: no IQ of voice boxes is kept at all (not even 0.25 s); MARK/SNAP on a voice box saves the spectrogram only; raw IQ retention excludes voice bins before writing.
- (P2) No TX-capable software on the device: no WSJT-X GUI, fldigi, QSSTV or SoapyRemote; decode-only tools (jt9/wsprd, decode-only SSTV such as slowrx) instead. Bias-tee calls in librtlsdr are gated by a labd token; EEPROM bias default off.
- (P2) VNA/tinySA: no antenna sweeps on air, no exception; antenna checks are receive-only (noise, beacon, sun). The SWR/S11 menu page is only reachable in Bench mode with a load or DUT on the port.
- (P2) Battery safety: the home-built pack is never flown; pack containment (barrier, vent path, NTC charging window 0-45 C, supervised charging, storage at about 50 % SoC) is part of the design.

User decisions (18 Oct 2026, from the user directly; these override earlier defaults)
- Region: Europe. Consequences: QO-100 (Es'hail-2, 25.9E) is in coverage, so the QO-100 add-on (Othernet Bullseye TCXO LNB, F/75 ohm parts, horn materials, LNB injector choke >=1 A) is bought; IF-penetration check for DVB-T and LTE B28 near the LNB IF. Inmarsat-C: European ocean-region NCS, confirmed by the power-only NCS scan (1537-1545 MHz) before the egc-gate. SBAS = EGNOS. Regional profiles: US-only items (UAT 978, HD Radio, NOAA SAME/EAS) stay off; DAB+ on; civil time signals DCF77/MSF/TDF first. Still no city tables: the device computes everything from the GNSS fix.
- LimeSDR Micro M.2: KEPT ("Lime беремо"). The build default becomes the with-Lime configuration (T7 1 TB, Lime parts, third HMC7992, CPU7 isolation, 4 GiB ring + 3 GiB burst, J21 desolder only after the soak test, case top band reprint). Trade-offs the user accepts: about 1.9 h typical session instead of 3.3 h (model), about $596-681 more. Lime TX stays blocked (LimeSuiteNG patch; receive-only rule). Acceptance tests within the 30-day guarantee (riser 8 GT/s x1, 50 warm + 20 cold boots, zero AER errors in 60 min, zero limeTRX drops during LRPT+HRPT, VCC_5V_PERI <= 14 W). Crowd Supply refunds in full only before shipment (ships 15 Dec 2026): do not let the slot lapse, decide on any analog before 1 Dec 2026.
- The Lime is also included in the P5 analog search: a cheaper part may replace it only if it is not worse in RX coverage (0.3-3.8 GHz incl. S-band), 56 MHz bandwidth, 12-bit ADC, NF/IIP3, form factor/interface, arm64 driver, power, and blockable TX.
